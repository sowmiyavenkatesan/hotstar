from django.conf.urls import url

from . import views


urlpatterns = [
    url('movie/', views.movie, name='movie'),
    url('inc/', views.inc, name='inc'),
    url('nemo/', views.nemo, name='nemo'),
    url('conjuring/', views.conjuring, name='conjuring'),
    url('alladin/', views.alladin, name='alladin'),
    url('wish1/',views.wish1, name='wish1'),
    url('wishing/',views.wishing, name='wishing'),
    url('kids/',views.kids, name='kids'),
    url('tamil/',views.tamil, name='tamil'),
    url('kiddo/',views.kiddo, name='kiddo'),
    url('',views.home, name='home'),

]
