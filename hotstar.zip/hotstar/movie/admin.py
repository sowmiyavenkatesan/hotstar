from django.contrib import admin

from .models import watch,wish
admin.site.register(watch)
admin.site.register(wish)
