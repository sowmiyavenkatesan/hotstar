from django.db import models

class wish(models.Model):
    wishlist=models.CharField(max_length=250)

    def __str__(self):
        return self.wishlist
class watch(models.Model):
    watchlist=models.CharField(max_length=250)

    def __str__(self):
        return self.watchlist
